package com.task.nytimes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

public class WelcomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        Button swipe_up = findViewById(R.id.swipe_up);
        swipe_up.setOnClickListener(view -> {
            startActivity(new Intent(WelcomeActivity.this, SigninActivity.class));
        });
    }
}