package com.task.nytimes.adapters;

import android.widget.ImageView;

import androidx.databinding.BindingAdapter;

import com.bumptech.glide.Glide;
import com.task.nytimes.R;

public class BindingAdapterUtils {
    @BindingAdapter({"bind:imageUrl"})
    public static void loadImage(ImageView view, String url) {
        view.setImageResource(0);
        Glide.with(view.getContext()).load(url).placeholder(R.drawable.loading).into(view);
    }
}