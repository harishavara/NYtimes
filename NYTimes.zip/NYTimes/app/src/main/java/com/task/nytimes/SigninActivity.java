package com.task.nytimes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SigninActivity extends AppCompatActivity {

    EditText editText_UserName, editText_Password;
    TextView login_textView;
    ImageView login_Button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editText_UserName = findViewById(R.id.editText_userName);
        editText_Password = findViewById(R.id.editText_password);

        login_textView = findViewById(R.id.textView_slideup);
        login_Button = findViewById(R.id.button_login);

        login_textView.setOnClickListener(view -> checkValidationAndLaunch());

        login_Button.setOnClickListener(view -> checkValidationAndLaunch());

    }

    private void checkValidationAndLaunch() {
        String user_name = editText_UserName.getText().toString();
        String password = editText_Password.getText().toString();

        if (user_name.isEmpty()) {
            Toast.makeText(SigninActivity.this, "Please enter valid username", Toast.LENGTH_SHORT).show();
        } else if (isValidPassword(password)) {
            Toast.makeText(SigninActivity.this, "Please enter 8 digit Password", Toast.LENGTH_SHORT).show();
        } else {
            startActivity(new Intent(SigninActivity.this, DashBoardActivity.class));
        }
    }

    private boolean isValidPassword(String password) {
        Pattern pattern;
        Matcher matcher;
        final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{4,}$";
        pattern = Pattern.compile(PASSWORD_PATTERN);
        matcher = pattern.matcher(password);

        return matcher.matches();
    }
}