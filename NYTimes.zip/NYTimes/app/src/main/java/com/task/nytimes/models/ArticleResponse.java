
package com.task.nytimes.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ArticleResponse {

    @SerializedName("response")
    @Expose
    private Document document;

    public Document getDocument() {
        return document;
    }
}
