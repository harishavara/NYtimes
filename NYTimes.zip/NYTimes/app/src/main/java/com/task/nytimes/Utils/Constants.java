package com.task.nytimes.Utils;

public class Constants {
    public static final String BASE_URL = "https://api.nytimes.com/";
    public static final String API_KEY = "pBvzSLrEnsyldIW0JncjP5FGVfM2BIcJ";
    public static String TAG = "NyTimes";
}